/**************************************************************************
*       Copyright (c) 2006, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    VpnStats.h
*  Date:    08/2006
*
***************************************************************************
*
*   VPN Statistics class implementation for the Client API.
*
***************************************************************************/
#ifndef _VPNSTATS_
#define _VPNSTATS_

#include "VPNStatsBase.h"


/**
 * Use this class to retrieve statistics related to the tunnel and
 * protocol being used.
 *
 * The class has two uses: it provides a consistent localized label
 * definition mechanism and it uses this label mechanism to do
 * values lookups.
 *
 * Labels are automatically localized at application startup.
 * See the AnyConnect Release notes for additional information on localization.
 *
 * To retrieve a value for one of the labels, use the method getStatValue().
 * For example, to get Time connected use: getStatValue(VPNStats::TimeConnected)
 */


class VPN_VPNAPI VPNStats : public VPNStatsBase
{
    public:

        /**
         * Get a list of Secure Routes.
         * Method returns a list of RouteInfo pointers
         */
        const std::list<RouteInfo *> &getSecureRoutes();

        /**
         * Get a list of Nonsecure Routes.
         * Method returns a list of RouteInfo pointers
         */
        const std::list<RouteInfo *> &getNonsecureRoutes();

        /**
         * Get a list of protocol Info objects.
         * Method returns a list of ProtocolInfo pointers
         */
        const std::list<ProtocolInfo *> &getProtocolInfo();

        /** 
        * Get a list of firewall Info objects.
        * Method returns a list of FirewallInfo pointers
        */
        const std::list<FirewallInfo *> &getFirewallInfo();

        /**
         * Method used to retrieve statistics by name.
         */
        const tstring &getStatValue(tstring &label);

        /**
         * Return a translated stats label.  As an example, passing
         * VPNStats::State will return a translated label for State text.
         *
         * NOTE: Do not use this translated label to retrieve stats
         *       values; it is meant only as a label translation mechanism.
         */
        static tstring getTranslatedLabel(tstring &label);

        //
        // These static localized strings can be used in conjunction with the
        // getStatValue method to retrieve VPN statisitics.
        //
        static tstring State;           /**< Current state (see ::VPNState) of
                                             the VPN tunnel. */
        static tstring TimeConnected;   /**< Time hh:mm:ss the VPN tunnel has
                                             been active. */

        // 
        // Data byte/packet counts, does not include encap/encrypt overhead
        //
        static tstring BytesSent;       /**< Bytes sent to the remote network. */
        static tstring BytesReceived;   /**< Bytes received from the remote
                                             network. */
        static tstring PacketsSent;     /**< Packets sent to the remote
                                             network. */
        static tstring PacketsReceived; /**< Packets received from the remote
                                             network. */

        //
        // Control byte/packet count include size of DPD/Keepalive/etc
        //
        static tstring ControlBytesSent;        /**< Control bytes sent to the
                                                     remote gateway. */
        static tstring ControlBytesReceived;    /**< Control bytes received
                                                     from the remote gateway. */
        static tstring ControlPacketsSent;      /**< Control packets sent to the
                                                     remote gateway. */
        static tstring ControlPacketsReceived;  /**< Control packets received
                                                     from the remote gateway. */

        //
        // Encrypted byte counts include both control and data, as well as 
        // encryption and encapsulation headers
        //
        static tstring EncryptedBytesSent;      /**< Encrypted bytes sent to the
                                                     remote network. */
        static tstring EncryptedBytesReceived;  /**< Encrypted bytes received
                                                     from the remote network. */
        static tstring EncryptedPacketsSent;    /**< Encrypted packets sent to the
                                                     remote network. */
        static tstring EncryptedPacketsReceived;/**< Encrypted packets received
                                                     from the remote network. */

        //
        // Encrypted byte counts include both control and data (if protocol
        // is TLS), as well as encryption and encapsulation headers
        //
        static tstring CompressedBytesSent;      /**< Compressed bytes sent
                                                      to the remote network. */
        static tstring CompressedBytesReceived;  /**< Compressed bytes received
                                                      from the remote network. */
        static tstring CompressedPacketsSent;    /**< Compressed packets sent
                                                      to the remote network. */
        static tstring CompressedPacketsReceived;/**< Compressed packets
                                                      received from the remote
                                                      network. */

        static tstring InboundDiscarded;    /**< Incoming discarded bytes. */
        static tstring OutboundDiscarded;   /**< Outgoing discarded bytes. */
        static tstring InboundBypassed;     /**< Incoming skipped bytes. */
        static tstring OutboundBypassed;    /**< Outgoing skipped bytes. */

        static tstring ClientAddress;   /**< Client IPv4 address. */
        static tstring ServerAddress;   /**< Remote gateway IP address. */
        static tstring ClientAddressV6; /**< Client IPv6 address. */

        static tstring ServerHostName;  /**< Host name of the remote gateway. */
        static tstring ProxyAddress;    /**< Proxy server IP address. */
        static tstring ProxyHostName;   /**< Proxy server host name. */
        static tstring ProxyPort;       /**< Port used for communicating with
                                             proxy server. */
        static tstring TunnelingMode;   /**< Mode IPv4 traffic is being passed over
                                             the tunnel.  Values are "Tunnel All Traffic",
                                             "Split Include", "Split Exclude",
                                             "Drop All Traffic" or "Bypass All Traffic". */
        static tstring TunnelingModeV6; /**< Mode IPv6 traffic is being passed over
                                             the tunnel.  Values are "Tunnel All Traffic",
                                             "Split Include", "Split Exclude",
                                             "Drop All Traffic" or "Bypass All Traffic". */

        static tstring Enabled;     /**< */
        static tstring Disabled;    /**< */
        static tstring Unconfirmed;     /**< Used for Secure Mobility Solution. If the 
                                             WSA is not reachable from the agent, it might be 
                                             due to private side proxy configuration. In such a case
                                             report Unconfirmed to the UI */

        static tstring FipsMode;        /**< FIPS mode (Federal security standard).
                                             Values are "Enabled" or "Disabled" */

        static tstring TrustedNetworkDetectionMode;  /** < Trusted Network Detection.
                                                           Values are "Enabled" or "Disabled" */
        static tstring AlwaysOnMode;    /**< Always On. Values are "Enabled" or 
                                             "Disabled" */

        static tstring NetworkStatus;     /**< Network Status.
                                               Values include are: "No Networks Detected",
                                                                   "DNS Services Unavailable",
                                                                   "Web Authentication Required",
                                                                   "Proxy Authentication Required",
                                                                   "Access Restricted",
                                                                   "Access Unrestricted" */

        static tstring DAPMessage;     /**< DAP message received from gateway.  Used for Quarantine
                                            mode, etc. */

        static tstring MUSHost;        /**< MUS Host delivered from secure gateway. */
        static tstring MUSStatus;      /**< MUS Status: Enabled, Disabled. */

        static tstring AdministrativeDomain;   /**<Administrative Domain Name: 
                                                   - domain name of the SG that the user connects to for the first time
                                                   - "Admin Defined" if there are authorized SGs specified in 
                                                     the local policy file
                                                   - "Not Applicable" otherwise. */

        static tstring ProfileName;      /**< Active profile name. */

        VPNStats();

        virtual ~VPNStats();

};


#endif // _VPNSATS_
