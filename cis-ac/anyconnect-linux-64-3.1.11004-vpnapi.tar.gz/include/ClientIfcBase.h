/**************************************************************************
*       Copyright (c) 2006, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    ClientIfcBase.h
*  Author:  Chris Fitzgerald
*  Date:    08/2007
*
***************************************************************************
*
*   Client Interface Base class implementation for the Client API.
*
***************************************************************************/

// The ClientIfcBase class contains the majority of private methods and members.
// The purpose of this class is to hide all but the necessary methods from
// being exposed.
//

#ifndef _CLIENTIFCBASE_
#define _CLIENTIFCBASE_

#include <list>
#include <vector>

/*
 * When changing the SCRIPTING_SUPPORTED definition, you MUST also update GenDefs.h!
 * We duplicate this definition here due to the manner in which we distribute our
 * code to partners; we cannot include GenDefs.h from here.
 */
#if !defined(PLATFORM_APPLE_SSLVPN) && !defined(PLATFORM_ANDROID)
#define SCRIPTING_SUPPORTED
#endif

#include "api.h"
#include "PreferenceUpdate.h"

class ConnectPromptInfo;
class ConnectMgr;
class MsgWithArg;
class VPNStats;
class AgentIfc;
class ProfileMgr;
class ApiThread;
class EventMgr;
class PreferenceMgr;
class PreferenceInfo;
class UserPreferences;
class CScriptingMgr;
class CManualLock;
class ApiThread;
class ProxyIfc;
class CIpcMessage;
class SCEPIfc;
class CertObj;
class CExecutionContext;
class HostEntry;

#if !defined(PLATFORM_APPLE_SSLVPN)
class CStoragePath;
#endif

#ifdef ANYCONNECT_USE_SNAK
class PluginLoader;
class SNAK_StoragePlugin;
class SNAK_CertPlugin;
class SNAK_SocketPlugin;
#endif

class VPN_VPNAPI ClientIfcBase : private IPreferenceUpdateCB
{
    friend class EventMgr;

    protected:

        virtual void StatsCB(VPNStats &stats) = 0;

        virtual void StateCB(const VPNState state,
                             const tstring stateString) = 0;

        virtual void BannerCB(const tstring &banner) = 0;

        virtual void NoticeCB(const tstring notice,
                              const MessageType type) = 0;

        virtual void ExitNoticeCB(const tstring &tstrNotice,
                                  const int returnCode);

        virtual void ServiceReadyCB() = 0;

        virtual void UserPromptCB(ConnectPromptInfo &ConnectPrompt) = 0;

        virtual void WMHintCB(const WMHint hint,
                              const WMHintReason reason);

        virtual void deliverWebLaunchHostCB(const tstring &activeHost);

        virtual void EventAvailable();

#ifdef PLATFORM_ANDROID
        virtual void ClientCertificateCB(std::vector< std::pair<uint32_t, uint8_t*> > certList) = 0;
        virtual void AgentDetachedCB();
#endif

        virtual void ImportPKCS12ResultCB(bool bResult, const tstring &strError);

        virtual void CertBlockedCB(const tstring &rtstrUntrustedServer) = 0;
        virtual void CertWarningCB(const tstring &rtstrUntrustedServer,
                                   const std::list<tstring> &rltstrCertErrors,
                                   bool bAllowImport) = 0;
        
        AgentIfc &getAgentIfc();

        ClientIfcBase();


    public:

        virtual bool attach(bool SBL = false,
                            bool isGUI = true,
                            bool requestFullCapabilities = true,
                            bool suppressAutoConnect = true);

        virtual void detach();

        virtual void ProcessEvents();

        virtual bool hasFullCapabilities();

        virtual bool isConnected();

        virtual bool isAvailable();

        virtual std::list<tstring> getHostNames();

        virtual tstring getDefaultHostName();

#if defined (PLATFORM_ANDROID)
        virtual bool connect(tstring host, const CertAuthMode mode=CertAuth_Automatic, const tstring &hash="");

		bool connect(tstring host, unsigned int origin, const CertAuthMode mode=CertAuth_Automatic, const tstring &hash="");
#else
        virtual bool connect(tstring host);

		bool connect(tstring host, unsigned int origin);
#endif

        virtual bool setNewTunnelGroup(const tstring & group);

        virtual void disconnect();

        virtual void resetStats();

        virtual void getState();

        VPNState getCurrentState();
        VPNSubState getCurrentSubState();
        VPNSubState getPreviousSubState();

        tstring getStateText();
        static tstring getNoticeTypeText(MessageType msgType);

        static tstring getStateText(VPNState state,
                                    VPNSubState subState = VPNSS_NORMAL,
                                    NETENV_STATE netEnvState = NES_NETWORK_ACCESSIBLE);

        void setNetworkStates(NETENV_STATE netEnvState, 
                              NETCTRL_STATE netCtrlState,
                              NETWORK_TYPE netType,
                              bool bUpdateUI);
        void refreshOperatingModeForCurrentNetStates();
        NETENV_STATE getCurrentNetEnvState();
        NETENV_STATE getPreviousNetEnvState();
        NETCTRL_STATE getCurrentNetCtrlState();
        NETWORK_TYPE getCurrentNetType();

        static tstring getNetCtrlText(NETCTRL_STATE netCtrlState);
        static tstring getNetEnvText(NETENV_STATE netEnvState,
                                     bool bSimple = false);
        static tstring getNetTypeText(NETWORK_TYPE netType);
        static tstring getQuarantinedStatusText();
        static tstring getNetworkStatusSimpleText(const NETENV_STATE netEnvState,
                                                  const NETCTRL_STATE netCtrlState);

        // can't be static due to requiring operating mode information
        tstring getNetworkStatusText(const VPNState state,
                                     const VPNSubState subState,
                                     const NETENV_STATE netEnvState,
                                     const NETCTRL_STATE netCtrlState);

        PreferenceInfo &getPreferences();

        bool savePreferences();

        virtual void startStats();

        virtual void stopStats();

        virtual void UserSubmit();

        void setBanner(const tstring &banner);
        void setBannerResponse(bool bResponse);
        bool getUserResponse();
        bool isUserResponseSet();

        void setCertBlocked(const tstring &tstrUntrustedServer);
        void setCertWarning(const tstring &tstrUntrustedServer,
                            const std::list<tstring> &ltstrCertErrors,
                            bool bAllowImport);
        bool getCertImportResponse();

        void setUserPrompt(ConnectPromptInfo &ConnectPrompt);

#ifdef PLATFORM_ANDROID
        void setClientCertResponse(std::vector< std::pair<uint32_t, uint8_t*> > &derList);
#endif

        void setImportPKCS12Result(bool bResult, const tstring &strError);

        void setCertBlockedResponse(bool bUnlock);
        void setCertWarningResponse(bool bConnect, bool bImportCert);

        void insertStateToConnectPrompt(ConnectPromptInfo &ConnectPrompt);

        void ExitNotice(const tstring &tstrNotice, const int code = 0);

        void notice(const tstring tstrNotice,
                    const MessageType type = MsgType_Info,
                    bool bClearLastMsg = false);

        void notice(MsgWithArg &notice,
                    const MessageType type = MsgType_Info,
                    bool bClearLastMsg = false);

        void getStats(void);

        void setStats(VPNStats &stats);

        void exportStats(const tstring &tstrFilePath);

        void setState(VPNState state,
                      VPNState previousState,
                      VPNSubState subState = VPNSS_NORMAL,
                      bool bUpdateStateMsg = true,
                      bool bOnlyUpdateUI = false);

        void setWMHint(WMHint hint,
                       WMHintReason reason);

        bool isLastConnectType (const ConnectPromptType connPromptType);

        bool isOperatingMode(OperatingMode opMode);
        void setOperatingMode(OperatingMode opMode);
        void unsetOperatingMode(OperatingMode opMode);

        bool CanRemediateCaptivePortal();

        bool isUsingEventModel();

        time_t getLastDisconnectTime();

        ConnectPromptInfo getConnectPromptInfo();

        void setStandaloneConnection(bool isStandalone);

        void deliverActiveHost(const tstring &activeHost,
                               ConnectProtocolType vpnProtocol = PROTOCOL_TYPE_UNKNOWN);

        bool isVPNServiceReady();

        // reset last disconnect time indicator.
        //
        void resetLastDisconnectTime(time_t time = 1);

        void processMinimize();
        
        // cert enrollment
        void setEnrollClientCert(CertObj* pCert);

        // Show user banner for cert import warning on linux
        // SCEPIfc to ConnectMgr
        void linuxCertImportWarnUser();

        // Response to cert warning on linux
        // ConnectMgr to SCEPIfc
        void linuxCertImportWarnUserResponse(bool bAccept);

        void setDefaultHost(tstring &host);

#ifdef PLATFORM_ANDROID
        bool requestClientCertificates();
#endif

        bool requestImportPKCS12(const std::vector<unsigned char> &der);

        bool requestImportLocalization(const tstring tstrLocale,
                                       const std::vector<unsigned char> &MoFileData);

        // Start the Automatic Headend Selection operation
        void startAHS(const unsigned int uiReason, 
                      const ProxyIfc& proxy);
        // statusReturnCode is a long to match the current type of STATUSCODE.
        // It is not using a STATUSCODE directly so that we do not have to
        // expose the header files for STATUSCODEs to ClientIfcBase.h
        void AHSSelectedHost(const unsigned int uiReason,
                             const std::vector<tstring> &headendList,
                             const long statusReturnCode,
                             const tstring& extraInfo);
        std::vector<tstring> getAHSHostList();
        unsigned int getAHSState();
        bool isAHSHasRun();

        bool suppressConnectionErrorPopups();

        tstring getCaptivePortalDetectedMsg();        

        void setProxyAuthPrompts(ProxyIfc* pProxy,
                                 const tstring& promptMsg);


        bool handleIpcMessage(CIpcMessage *pIpcMessage);

        bool IsCsdTokenVerified() const;

        bool isConnectRequestActive();

        virtual ~ClientIfcBase();

        tstring getConnectHost();

    private:
        CExecutionContext* m_pExecutionContext;

        AgentIfc *mo_AgentIfc;

        ConnectMgr *mo_ConnectMgr;

        ApiThread  *mo_ConnectThread;

        EventMgr  *mo_EventMgr;

        PreferenceMgr *mo_PreferenceMgr;

        ConnectPromptInfo *mp_currentConnectPromptInfo;

        PreferenceInfo *mo_EditablePrefs;

#if defined(SCRIPTING_SUPPORTED)
        CScriptingMgr *mo_ScriptingMgr;
#endif // SCRIPTING_SUPPORTED
#ifndef PLATFORM_APPLE_SSLVPN
        SCEPIfc* m_pSCEPIfc;
        bool m_bInformedAgentOfSCEP;
        CStoragePath* m_pStoragePath;
#endif // !PLATFORM_APPLE_SSLVPN

#ifdef ANYCONNECT_USE_SNAK
        PluginLoader *m_pPluginLoader;
        SNAK_CertPlugin *m_pSNAKCert;
        SNAK_SocketPlugin *m_pSNAKSocket;
        SNAK_StoragePlugin *m_pSNAKStorage;

        bool mb_SNAKInitialized;
#endif

        bool mb_PreferenceMgrCreated;
        bool mb_StandaloneConnection;
        bool mb_UsingEventModel;
        bool mb_UserResponse;
        bool mb_IsUserResponseSet;
        bool mb_PerformedAutoCertEnrollment;
        tstring ms_PostEnrollmentConnectHost;
        bool mb_CaptivePortalMsgDisplayed;
        bool m_bSuppressMinimizeOnConnect;
        bool m_bSuppressConnectionErrorPopups;
        bool m_bLastConnectionAutomatic;
        bool m_bImportCertResp;

        unsigned int mui_OperatingMode;
        NETENV_STATE m_currentNetEnvState;
        NETENV_STATE m_previousNetEnvState;
        NETCTRL_STATE m_currentNetCtrlState;
        NETWORK_TYPE m_currentNetType;

        tstring ms_message;

        time_t m_disconnectTime;

        static std::string ms_ThreadName;

        CManualLock* m_pClientIfcStateLock;
        CManualLock* m_pClientIfcLock;
        CManualLock* m_pClientIfcPromptsLock;
        CManualLock* m_pClientIfcOpModeLock;
        CManualLock* m_pClientIfcAHSLock;
        CManualLock* m_pClientIfcConnectModeLock;
        CManualLock* m_pClientIfcInformAgentOfSCEPLock;

        std::vector<tstring> msl_AHSSelectedHosts;
        ApiThread* m_pAHSThread;
        unsigned int m_uiAHSState;

        static volatile bool mb_deleteFirstPass;

        ConnectMgr &getConnectMgr();

        ProfileMgr &getProfileMgr();
        UserPreferences &getUserPreferences();

        void displayAgentAttachMessage();

        void setLastDisconnectTime(time_t time);

        void setCurrentStatePrompts(const VPNState state, 
                                    const VPNState prevState,
                                    const VPNSubState subState,
                                    const bool bUpdateStateMsg);
        void setCurrentStateErrorMessage(VPNState state, CONNECT_FAILURE_REASON cfr);
        void getStateMessage(const VPNState state, 
                             const VPNState prevState,
                             const VPNSubState subState,
                             const NETENV_STATE neState,
                             /*out*/ MsgWithArg& stateMessage);

        bool isStandaloneConnection();

        virtual void OnLoadPreferencesComplete();
        void RefreshPreferences(void);

        void displayAHSPrompt(const bool isComplete);
        void handleAHSPreferences(const unsigned int uiReason);
        void setAHSState(const unsigned int ahsState);

        bool autoConnectIfEnabled(const bool suppressAutoConnect);

        void clearUserSetResponseFlag();

#ifndef PLATFORM_APPLE_SSLVPN
        bool processSCEPIpcMessage(CIpcMessage *pIpcMessage);
        bool isSCEPRedirect();
        void processSCEPRedirect();
#endif // PLATFORM_APPLE_SSLVPN

        ClientIfcBase(const ClientIfcBase& other);
        ClientIfcBase& operator=(const ClientIfcBase& other);

#ifdef ANYCONNECT_USE_SNAK
        bool initializeSNAK();
#endif

};


#endif // _CLIENTIFCBASE_
