/**************************************************************************
*       Copyright � 2009, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    PreferenceUpdate.h
*  Author:  Ivonne Olavarrieta Arruti
*  Date:    06/2009
*
***************************************************************************
*
*   Preference Update Interface declaration for the Client API. 
*
***************************************************************************/

#ifndef _PREFERENCEUPDATE_
#define _PREFERENCEUPDATE_

#include "api.h"

class VPN_VPNAPI IPreferenceUpdateCB
{    
public:
    /*
    ** IPreferenceUpdateCB::OnLoadPreferencesComplete
    **   Callback method invoked when the loadPreferences operation has completed
    **   and preferences have been reloaded.
    **
    **   NOTE: Implementations of this callback must be thread safe.
    */
    virtual void OnLoadPreferencesComplete() = 0;

protected:
    // Deletions should not be done via a callback Interface base class pointer.
    // By declaring the destructor as protected, we prevent this.
    //
    virtual ~IPreferenceUpdateCB() {}
};



#endif // _PREFERENCEUPDATE_

